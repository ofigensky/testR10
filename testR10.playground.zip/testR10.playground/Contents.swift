import Foundation

var a = "aaaaabbbbbbbbcd"
var b = "abcaaaaaaaaaaaaaaaaaabbc"
var c = "ab"

extension String {

    func compressed() -> String {
        
        var result = ""
        var counter = 1
        var storedChar: Character? = nil
        for (i, currentChar) in self.enumerated() {
            if storedChar == nil {
                
                storedChar = currentChar
            } else if storedChar == currentChar { // считаем повторяющиеся символы

                counter += 1

            } else { // присоединяем
                
                result += String(storedChar!) + String(counter)
                storedChar = currentChar
                counter = 1

            }

            if i == self.count-1 {
                
                result += String(storedChar!) + String(counter)

            }
        }

        if result.count >= self.count {
            return self
        }

        return result
    }
}

a.compressed()
b.compressed()
c.compressed()
